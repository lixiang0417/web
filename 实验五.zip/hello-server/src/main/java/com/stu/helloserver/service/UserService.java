package com.stu.helloserver.service;

import com.stu.helloserver.common.Result;
import com.stu.helloserver.dto.UserDTO;

public interface UserService {
    // 注册
    Result<String> register(UserDTO userDTO);
    // 登录
    Result<String> login(UserDTO userDTO);
    // 根据ID查询用户
    Result<String> getUserById(Long id);
}