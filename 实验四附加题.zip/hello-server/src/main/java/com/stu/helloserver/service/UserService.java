package com.stu.helloserver.service;

import com.stu.helloserver.common.Result;
import com.stu.helloserver.dto.UserDTO;

public interface UserService {
    Result<String> register(UserDTO userDTO); // 注册
    Result<String> login(UserDTO userDTO);    // 登录
}