package com.stu.helloserver.interceptor;

import com.stu.helloserver.common.Result;
import com.stu.helloserver.common.ResultCode;
import com.stu.helloserver.utils.JwtUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 1. 处理跨域预检请求
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        // 2. 获取Token
        String token = request.getHeader("Authorization");

        // 3. 无Token/格式错误 → 拦截，返回401
        if (token == null || !token.startsWith("Bearer ")) {
            response.setContentType("application/json;charset=UTF-8");
            Result<String> result = Result.error(ResultCode.TOKEN_INVALID);
            response.getWriter().write(new ObjectMapper().writeValueAsString(result));
            return false;
        }

        // 4. 验证Token有效性
        String realToken = token.substring(7);
        String username = jwtUtils.extractUsername(realToken);
        if (username == null || jwtUtils.isTokenExpired(realToken)) {
            response.setContentType("application/json;charset=UTF-8");
            Result<String> result = Result.error(ResultCode.TOKEN_INVALID);
            response.getWriter().write(new ObjectMapper().writeValueAsString(result));
            return false;
        }

        // 5. Token有效 → 放行
        return true;
    }
}