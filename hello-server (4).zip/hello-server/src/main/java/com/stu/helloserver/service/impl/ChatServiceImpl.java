package com.stu.helloserver.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.stu.helloserver.dto.ChatRequestDTO;
import com.stu.helloserver.service.ChatService;
import com.stu.helloserver.vo.ChatResponseVO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

@Service
public class ChatServiceImpl implements ChatService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final StringRedisTemplate stringRedisTemplate;

    @Value("${dashscope.api-key}")
    private String apiKey;

    @Value("${dashscope.model:qwen3.7-plus}")
    private String model;

    // 保留的最大历史轮数
    private static final long MAX_HISTORY_ROUNDS = 3;

    public ChatServiceImpl(StringRedisTemplate stringRedisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
    }

    @Override
    public ChatResponseVO chat(ChatRequestDTO requestDTO) {
        String sessionId = requestDTO.getSessionId();
        String message = requestDTO.getMessage();
        String redisKey = "chat:session:" + sessionId;

        // 1. 读取 Redis 中的历史聊天记录
        List<String> records = stringRedisTemplate.opsForList().range(redisKey, 0, -1);

        // 2. 构建 messages 数组：系统消息 + 历史记录 + 当前问题
        JSONArray messages = new JSONArray();

        // 系统消息
        JSONObject systemMsg = new JSONObject();
        systemMsg.put("role", "system");
        systemMsg.put("content", "你是一名专业、友好、简洁的中文智能助手，请结合历史对话上下文回答问题");
        messages.add(systemMsg);

        // 历史消息（从 Redis 中读取的拼接文本，拆成 user/assistant 对）
        if (records != null) {
            for (String record : records) {
                // record 格式: "用户:xxx\n助手:xxx"
                String[] parts = record.split("\n助手:", 2);
                if (parts.length == 2) {
                    String userPart = parts[0].replaceFirst("^用户:", "").trim();
                    String assistantPart = parts[1].trim();

                    JSONObject histUser = new JSONObject();
                    histUser.put("role", "user");
                    histUser.put("content", userPart);
                    messages.add(histUser);

                    JSONObject histAssistant = new JSONObject();
                    histAssistant.put("role", "assistant");
                    histAssistant.put("content", assistantPart);
                    messages.add(histAssistant);
                }
            }
        }

        // 当前用户问题
        JSONObject userMsg = new JSONObject();
        userMsg.put("role", "user");
        userMsg.put("content", message);
        messages.add(userMsg);

        // 3. 调用 DashScope API
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("messages", messages);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("Authorization", "Bearer " + apiKey);

        HttpEntity<String> request = new HttpEntity<>(body.toJSONString(), headers);

        ResponseEntity<String> response = restTemplate.exchange(
                "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
                HttpMethod.POST,
                request,
                String.class
        );

        // 4. 解析大模型回答
        String answer = "抱歉，我暂时无法回答这个问题。";
        JSONObject respJson = JSON.parseObject(response.getBody());
        JSONArray choices = respJson.getJSONArray("choices");
        if (choices != null && !choices.isEmpty()) {
            JSONObject choice = choices.getJSONObject(0);
            JSONObject innerMsg = choice.getJSONObject("message");
            if (innerMsg != null) {
                answer = innerMsg.getString("content");
            }
        }

        // 5. 将本轮对话记录写入 Redis
        String recordText = "用户:" + message + "\n助手:" + answer;
        stringRedisTemplate.opsForList().rightPush(redisKey, recordText);

        // 6. 只保留最近 3 轮对话，超出部分截断
        Long size = stringRedisTemplate.opsForList().size(redisKey);
        if (size != null && size > MAX_HISTORY_ROUNDS) {
            stringRedisTemplate.opsForList().trim(redisKey, size - MAX_HISTORY_ROUNDS, size - 1);
        }

        return new ChatResponseVO(message, answer);
    }
}
